# Reactor and life-support production handoff

Approved drop-in modules: reactor **2x2**, life support **1x2**. No content
footprint changes. Geometry is grounded, below the 1.85-unit walls, with no
floor slab. Healthy reactor top: 1.781; life-support top: 1.480 tile units.

## Files

- `1x/sprites/`: native colour/glow atlas twins, reactor 2048x98 and life
  support 2048x96. Both use the established 4096 maximum-side packer.
- `1x/manifest.fragment.json`: 40 unique frames, 60 entries including aliases.
- `1x/frames/`: final aligned colour/glow PNGs and metadata for each frame.
- `1x/reactor.blend`, `1x/life_support.blend`: editable approved healthy r0.
- `1x/integration.json`: asset IDs, state precedence, aliases and runtime notes.
- `1x/settings.json`, `parameters.json`, `build.json`: provenance and dimensions.
- `review/`: images drawn from the actual atlas pixels, all damage rotations,
  a flicker GIF and the validation report.
- `source/`: minimal standalone pipeline/model snapshot and locked approved
  reference frames. `CHECKSUMS.sha256` covers the entire package.

## Rendering contract

Blender **4.2.9 LTS**, two CPU threads, Cycles four samples, SS4, fixed project
orthographic camera (yaw45/elevation30), Standard/None colour management,
sun3.9 with shadows off, ambient.15, no bounces, exact standard environment
palette quantization and one-native-pixel prop outline. The core rendering
files were checked unchanged on main at 71d83c23953eda87b5f7cb0a77a45c8b63d73156.

Native tiles are **64x32**, displayed at **2x on the 128x64 game grid**.
Do not upscale the atlas or change its anchors during integration. One fixed
frame size and anchor covers every state in each asset/rotation; rotations may
have different anchors. Padding adds no floor geometry or visible marks.

The 22 approved colour/glow pairs are reproduced exactly inside the final
aligned frames. Only the 18 missing damage rotations were newly rendered.
Damaged and flicker geometry/alpha are exact matches. Unpowered, flicker-off
and destroyed frames contain no glow. Damage is made in r0 and rotated rigidly.

## Asset IDs and integration

| State | ID (`N` = 0..3) |
|---|---|
| Healthy, powered | `module.reactor.rN`, `module.life_support.rN` |
| Unpowered | append `.unpowered` |
| Damaged | append `.damaged` |
| Damage lights off | append `.damaged.flicker` |
| Destroyed | append `.destroyed` |

The bare legacy IDs (including old damaged/destroyed/flicker IDs) alias r0;
`.active` aliases powered healthy art without allocating more texture regions.
The content definition is `module.lifeSupport`, whose asset is `module.life_support`.

Copy the four atlas PNGs into `public/assets/1x/sprites/` and **merge** the
manifest fragment with the current manifest through the asset tooling. Keep
the existing footprints. Current main's `moduleAssets/stateArt` already supports
rotation and healthy `.unpowered` selection. Derelict ruin art supports damage
suffixes; live HP/flicker selection remains an integration concern. Use the
dark flicker variant for damaged machines while unpowered. Destroyed takes
precedence. A matching flicker schedule is 340ms lit / 170ms off, on render time.

No `src/`, live atlas or global manifest was changed by this handoff.

## Rebuild and validate

From `source/`, use the pinned Blender installed by `tools/blender/setup.sh`:

```sh
SPRITE_PREVIEW=0 SPRITE_SS=4 SPRITE_SAMPLES=4 blender -b -t 2 \
  --factory-startup --python-exit-code 1 \
  --python tools/blender/export_core_systems.py -- --out ../1x
python3 tools/blender/validate_core_systems.py --package ../1x \
  --report ../review/validation.json
```

Only one Blender process at a time on a shared machine. Rebuilds verify the
approval lock first and reuse approved frames; other frames have source-keyed
cache checkpoints. Geometry, materials and reference changes require a new
approval lock instead of silently reusing stale artwork.
